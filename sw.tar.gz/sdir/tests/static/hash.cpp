#include <ctti/detail/hash.hpp>
#include "static_test.hpp"

using namespace ctti::detail;
/*
EXPECT_EQ(fnv1a_hash("Mt5Kexny31n"), 0);
EXPECT_EQ(fnv1a_hash("OjSHjikPNYV"), 0);
*/
